import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


//open the manufacturer link in the product page
public class ManfacturerLink {

    WebDriver driver;


    @BeforeTest
    public void BeforeTest(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }

    @BeforeMethod
    public void BeforeMethod(){
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guideBar = driver.findElement(By.id("TourTip0"));
        WebElement exitButton = guideBar.findElement(By.className("pum-close"));
        exitButton.click();
        driver.findElement(By.id(("menu-item-561"))).click();
    }


    @Test
    public void Test() throws InterruptedException {



        driver.findElements(By.className("ec_image_link_cover")).get(6).click();
        driver.findElement(By.linkText("HDX")).click();
        Thread.sleep(3000);

       String ErrorPagetext= driver.findElement(By.className("sq-main-title")).getText();
       Assert.assertNotEquals(ErrorPagetext,"404 Error","The Manufacturer link opens an error page");









//
//        driver.findElement(By.className("ec_plus")).click();
//        driver.findElement(By.className("ec_plus")).click();
//        driver.findElement(By.className("ec_cartitem_update_button")).click();
//        Thread.sleep(3000);
//        int quantity= Integer.parseInt(driver.findElement(By.className("ec_quantity")).getAttribute("value"));
//        Assert.assertEquals(quantity,3,"Errror");






    }

    @AfterTest
    public void AfterTest(){
        driver.quit();

    }

}
