import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


//change the currency of the website
public class ChangeCurrency {

    WebDriver driver;


    @BeforeTest
    public void BeforeTest(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }

    @BeforeMethod
    public void BeforeMethod(){
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guideBar = driver.findElement(By.id("TourTip0"));
        WebElement exitButton = guideBar.findElement(By.className("pum-close"));
        exitButton.click();
        driver.findElement(By.id(("menu-item-561"))).click();
    }


    @Test
    public void Test() throws InterruptedException {



        driver.findElements(By.className("ec_image_link_cover")).get(6).click();
        WebElement Currencydropdown= driver.findElement(By.id("ec_currency_conversion"));
        Select dropdown = new Select(Currencydropdown);
        dropdown.selectByValue("EUR");
        //Thread.sleep(3000);

        driver.manage().timeouts().implicitlyWait(2000, java.util.concurrent.TimeUnit.SECONDS);








    }

    @AfterTest
    public void AfterTest(){
       // driver.quit();

    }

}
