import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TotalInCart {


        WebDriver driver;

        @BeforeTest
        public void beforeTest() {
        //sherif
        /*String path = System.getProperty("user.dir")+ "\\drivers\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", path);
        driver = new ChromeDriver();*/

        //String path="C:\\Users\\DELL\\IdeaProjects\\";
        // System.setProperty("webdriver.edge.driver", path +"Final Project\\Drivers\\msedgedriver.exe");

        String path=System.getProperty("user.dir")+ "\\Drivers\\msedgedriver.exe";
        System.setProperty("webdriver.edge.driver",path );
        driver=new EdgeDriver();
    }
        @BeforeMethod
        public void beforeMethod() {
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guidBar = driver.findElement(By.id("TourTip0"));
        WebElement closeButton = guidBar.findElement(By.className("pum-close"));
        closeButton.click();
    }
        @Test
        public void test() throws InterruptedException {
        driver.findElement(By.id("menu-item-561")).click();
        driver.findElement(By.id("ec_add_to_cart_5")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("a[href='https://academybugs.com/my-cart/']")).click();
        Thread.sleep(5000);

        String cartSubtotalWithDollarSign = driver.findElement(By.className("ec_cart_price_row_total")).getText();
        String cartSubtotalWithoutDollarSign = cartSubtotalWithDollarSign.replace("$", "");
        double cartSubtotal = Double.parseDouble(cartSubtotalWithoutDollarSign);

        String  shippingWithDollarSign = driver.findElement(By.id("ec_cart_shipping")).getText();
        String shippingWithoutDollarSign = shippingWithDollarSign.replace("$", "");
        double shipping = Double.parseDouble(shippingWithoutDollarSign);


        String  grandTotalWithDollarSign = driver.findElement(By.id("ec_cart_total")).getText();
        String grandTotalWithoutDollarSign = grandTotalWithDollarSign.replace("$", "");
        double grandTotal = Double.parseDouble(grandTotalWithoutDollarSign);

        Double expectedGrandTotal = cartSubtotal + shipping ;

        Assert.assertEquals(grandTotal,expectedGrandTotal, "The Final Summation at Cart has a problem");


    }

    }

