import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//check sign in button
public class SignInButton {

    WebDriver driver;


    @BeforeTest
    public void BeforeTest(){
        //edge
//        String path=System.getProperty("user.dir")+ "\\Drivers\\msedgedriver.exe";
//        System.setProperty("webdriver.edge.driver",path );
//        driver=new EdgeDriver();
        //chrome
//        String fullPath = System.getProperty("user.dir")+ "\\Drivers\\chromedriver.exe";
//        System.setProperty("webdriver.chrome.driver", fullPath);

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }

    @BeforeMethod
    public void BeforeMethod(){
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guideBar = driver.findElement(By.id("TourTip0"));
        WebElement exitButton = guideBar.findElement(By.className("pum-close"));
        exitButton.click();
        driver.findElement(By.id(("menu-item-561"))).click();
    }


    @Test
    public void Test() throws InterruptedException {


        //enter to the first product
        driver.findElements(By.className("ec_image_link_cover")).get(0).click();
        for(int i =0; i<=5; i++) {
            driver.findElement(By.tagName("body")).sendKeys(Keys.PAGE_DOWN);
            Thread.sleep(500);
        }
        Boolean SignInButton=driver.findElement(By.className("ec-widget-login")).isEnabled();
        Assert.assertFalse(SignInButton,"Error : SignIn Button Should be disabled untill enter the email & password");



    }

    @AfterTest
    public void AfterTest(){
        driver.quit();

    }

}
