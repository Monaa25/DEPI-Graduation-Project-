import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;




//check add to cart button
public class AddtoCart {

    WebDriver driver;


    @BeforeTest
    public void BeforeTest(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }

    @BeforeMethod
    public void BeforeMethod(){
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guideBar = driver.findElement(By.id("TourTip0"));
        WebElement exitButton = guideBar.findElement(By.className("pum-close"));
        exitButton.click();
        driver.findElement(By.id(("menu-item-561"))).click();
    }


    @Test
    public void Test() throws InterruptedException {


         WebElement Product=  driver.findElements(By.className("ec_image_link_cover")).get(0);
        String productUrl = Product.getAttribute("href");

        // click add to cart
         driver.findElement(By.id(("ec_add_to_cart_5"))).click();

         //System.out.println(productUrl);
         Thread.sleep(3000);


         //click view cart when appear
        driver.findElement(By.xpath("//a[@title=\"View Cart\"]")).click();
        Thread.sleep(3000);
        WebElement ProductInCart=driver.findElements(By.xpath("//a[@class='ec_cartitem_title']")).get(0);
        String ProductInCartUrl= ProductInCart.getAttribute("href");
       // System.out.println(ProductInCartUrl);

        Assert.assertEquals(productUrl,ProductInCartUrl,"Product not added successfully ");





    }

    @AfterTest
    public void AfterTest(){
        driver.quit();

    }

}
