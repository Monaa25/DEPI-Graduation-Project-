import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//buy product and add it 3 times
public class QuantityInCart {

    WebDriver driver;


    @BeforeTest
    public void BeforeTest(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }

    @BeforeMethod
    public void BeforeMethod(){
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guideBar = driver.findElement(By.id("TourTip0"));
        WebElement exitButton = guideBar.findElement(By.className("pum-close"));
        exitButton.click();
        driver.findElement(By.id(("menu-item-561"))).click();
    }

    @Test
    public void TestQ2() throws InterruptedException {


        //enter to the first product
        //driver.findElements(By.className("ec_image_link_cover")).get(0).click();
        //increase quantity inside
        //driver.findElement(By.className("ec_plus")).click();


        //check added msg
        //String MessageAddedtoCart = driver.findElement(By.className("ec_product_added_to_cart")).getText();
        //System.out.println(MessageAddedtoCart);

        // //*[@id="ec_product_page"]/div[2]/text()
        //Assert.assertEquals(MessageAddedtoCart,"Product successfully added to your cart.","Added to Cart Message didn't appear");


        // click add to cart
        /* driver.findElement(By.id(("ec_add_to_cart_5"))).click();
        //click view cart when appear
         Thread.sleep(3000);
        driver.findElement(By.xpath("//a[@title=\"View Cart\"]")).click();*/

        driver.findElements(By.className("ec_image_link_cover")).get(0).click();
        driver.findElement(By.xpath("//input[@value='ADD TO CART']")).click();
        Thread.sleep(3000);
        driver.findElement(By.className("ec_plus")).click();
        driver.findElement(By.className("ec_cartitem_update_button")).click();
        Thread.sleep(3000);
        int quantity= Integer.parseInt(driver.findElement(By.className("ec_quantity")).getAttribute("value"));
        Assert.assertEquals(quantity,2,"The Quantity is updated");

    }

    @Test
    public void TestQ3() throws InterruptedException {


        //enter to the first product
        //driver.findElements(By.className("ec_image_link_cover")).get(0).click();
        //increase quantity inside
        //driver.findElement(By.className("ec_plus")).click();


        //check added msg
        //String MessageAddedtoCart = driver.findElement(By.className("ec_product_added_to_cart")).getText();
        //System.out.println(MessageAddedtoCart);

        // //*[@id="ec_product_page"]/div[2]/text()
        //Assert.assertEquals(MessageAddedtoCart,"Product successfully added to your cart.","Added to Cart Message didn't appear");


        // click add to cart
        /* driver.findElement(By.id(("ec_add_to_cart_5"))).click();
        //click view cart when appear
         Thread.sleep(3000);
        driver.findElement(By.xpath("//a[@title=\"View Cart\"]")).click();*/

        driver.findElements(By.className("ec_image_link_cover")).get(0).click();
        driver.findElement(By.xpath("//input[@value='ADD TO CART']")).click();
        Thread.sleep(3000);
        driver.findElement(By.className("ec_plus")).click();
        driver.findElement(By.className("ec_plus")).click();
        driver.findElement(By.className("ec_cartitem_update_button")).click();
        Thread.sleep(3000);
        int quantity= Integer.parseInt(driver.findElement(By.className("ec_quantity")).getAttribute("value"));
        Assert.assertEquals(quantity,3,"The Quantity is updated to 2 again");

    }

    @AfterTest
    public void AfterTest(){
        driver.quit();

    }

}
