import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//check sign in fields
public class SignInUI {

    WebDriver driver;


    @BeforeTest
    public void BeforeTest(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }

    @BeforeMethod
    public void BeforeMethod(){
        driver.navigate().to("https://academybugs.com/");
        driver.manage().window().maximize();
        WebElement guideBar = driver.findElement(By.id("TourTip0"));
        WebElement exitButton = guideBar.findElement(By.className("pum-close"));
        exitButton.click();
        driver.findElement(By.id(("menu-item-561"))).click();
    }


    @Test
    public void Test() throws InterruptedException {


        //enter to the first product
        driver.findElements(By.className("ec_image_link_cover")).get(0).click();
        for(int i =0; i<=5; i++) {
            driver.findElement(By.tagName("body")).sendKeys(Keys.PAGE_DOWN);
            Thread.sleep(500);
        }
        //driver.findElement(By.className("ec-widget-login")).click();
        WebElement SignInButton=driver.findElement(By.className("ec-widget-login"));
        int ButtonYaxis=SignInButton.getLocation().getY();
        int ButtonHeight=SignInButton.getSize().getHeight();

        WebElement Footer=driver.findElement(By.className("sq-site-footer"));
        int FooterYaxis=Footer.getLocation().getY();
        //int FooterHeight=SignInButton.getSize().getHeight();
        //System.out.println(ButtonYaxis + " " +FooterYaxis);
        //System.out.println(ButtonHeight +  " " + FooterHeight);

        Assert.assertFalse(ButtonYaxis+ButtonHeight>FooterYaxis, " The Button is overlapping the footer");







        // Thread.sleep(3000);

        // Wait for the close button to be clickable

        //driver.findElement(By.id("popmake-4406")).sendKeys(Keys.PAGE_UP);
        //driver.findElement(By.className("popmake-close")).click();


    }

    @AfterTest
    public void AfterTest(){
        //driver.quit();

    }

}


