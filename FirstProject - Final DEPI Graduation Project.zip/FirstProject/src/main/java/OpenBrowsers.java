import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class OpenBrowsers {


    public static void main(String[] args) {

//        String path="C:\\Users\\DELL\\IdeaProjects\\";
//        System.setProperty("webdriver.edge.driver", path +"FirstProject\\Drivers\\msedgedriver.exe");
//        WebDriver driver=new EdgeDriver();
//        driver.navigate().to("https://academybugs.com");


//        String path="C:\\Users\\DELL\\IdeaProjects\\";
//        System.setProperty("webdriver.chrome.driver", path +"FirstProject\\Drivers\\chromedriver.exe");
//        WebDriver driver=new ChromeDriver();
//        driver.navigate().to("https://academybugs.com");


       // driver.findElement(By.linkText("Find Bugs")).submit();
        //driver.findElement(By.id(("ec_add_to_cart_5"))).click();
        //driver.findElement(By.name("btnK")).sendKeys(Keys.ENTER);
        //driver.findElement(By.name("btnK")).submit();
    }
}
